import React from 'react'
import ContactUs from '../components/ContactUs'
import { Box } from '@mui/material'

const ContactPage = () => {
  return (
    <Box>
      {' '}
      <ContactUs />
    </Box>
  )
}

export default ContactPage
