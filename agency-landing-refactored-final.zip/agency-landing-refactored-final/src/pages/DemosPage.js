import React from 'react'

import { Box } from '@mui/material'

const DemosPage = () => {
  return <Box sx={{ margin: '50px', textAlign: 'center' }}>Demos</Box>
}

export default DemosPage
