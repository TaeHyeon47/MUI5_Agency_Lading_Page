import React from 'react'

import { Box } from '@mui/material'

const PagePage = () => {
  return <Box sx={{ margin: '50px', textAlign: 'center' }}>Pages</Box>
}

export default PagePage
