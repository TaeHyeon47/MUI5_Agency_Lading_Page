import React from 'react'

import { Box } from '@mui/material'

const ServicesPage = () => {
  return <Box sx={{ margin: '50px', textAlign: 'center' }}>Services</Box>
}

export default ServicesPage
